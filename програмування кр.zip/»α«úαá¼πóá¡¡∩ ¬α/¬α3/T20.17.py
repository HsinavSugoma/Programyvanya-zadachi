import numpy as np
import numpy.random as rnd
import matplotlib.pyplot as ptl

if __name__ == '__main__':
    N = 100000

    x = rnd.uniform(-1, 1, N)
    y = rnd.uniform(0, 1, N)

    z = x**2 + y**2
    inside = z[z <= 1]

    L = len(inside)
    our_pi = 4*L/N

    print(f"pi = {our_pi}, error = {np.pi - our_pi}") # error - похибка

    X = np.linspace(-1, 1, 1000)
    Y = np.sqrt(1 - np.power(X, 2))
    ptl.plot(X, Y)

    ptl.plot(X, np.zeros_like(X), 'GRAY')
    ptl.plot(X, np.ones_like(X), 'GRAY')
    ptl.plot(-np.ones_like(100), np.linspace(0, 1, 100))
    ptl.plot(np.ones_like(100), np.linspace(0, 1, 100))

    ptl.scatter(x,y)

    ptl.axis([-1, 1, 0, 1])

    ptl.show()