import numpy as np
import numpy.random as rnd
import matplotlib.pyplot as ptl
@np.vectorize
def games(n):
    stake = 1

    A = rnd.randint(1, 7, 4*n)
    A.shape = (4, n)

    B = np.sum(A, axis=0)
    wins = np.sum(B <= 9)
    won_money = 10 * wins
    rtp = won_money / (n * stake)

    return rtp

if __name__ == '__main__':
    n = 100000
    mas = np.arange(1, n, 100)

    rtps = games(mas)

    ptl.plot(mas[::10], rtps[::10])
    ptl.show()


