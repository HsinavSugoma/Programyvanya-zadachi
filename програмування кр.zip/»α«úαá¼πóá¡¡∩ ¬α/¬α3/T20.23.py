import numpy as np
import numpy.random as rnd
import matplotlib.pyplot as ptl

if __name__ == '__main__':
    n = 10000

    A = np.arange(0, 12 * n, dtype=int)
    A.shape = (12, n)
    S = 0
    for i in range(n):
        B = rnd.choice(A[:,i], 3, replace=False)
        C = B[B % 3 == 0]
        S += (len(C) >= 2)

    print(f"Вірогiдність - {S/n:.02}")
